<template>
  <div>
    <h1>欢迎来到空页面！</h1>
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>

</style>