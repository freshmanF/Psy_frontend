export const API = {
    GENERATE: '/chat/generate',
}

export const BASE_URL = 'http://localhost:8080' 